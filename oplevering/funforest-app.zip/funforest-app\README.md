# 🌲 FunForest Seizoenskaart

Een mobiele app voor het FunForest klimbos: inloggen/registreren, je digitale
seizoenskaart met QR-code, bezoeken bijhouden, reserveringen maken en de
openingstijden & locaties bekijken.

## Vereisten

1. **Node.js 18 of nieuwer**: https://nodejs.org
2. **Expo Go** op je telefoon:
   - iPhone: App Store → "Expo Go"
   - Android: Play Store → "Expo Go"

## Starten (telefoon)

```bash
npm install
npx expo start
```

Scan daarna de QR-code met:

- **iPhone**: de Camera-app
- **Android**: de Expo Go-app

De app opent op je telefoon. Het eerste scherm is **Inloggen**; via
**Registreer nu** maak je een eigen account aan.

> Tip: telefoon en computer moeten op hetzelfde wifi-netwerk zitten.

## Starten (browser)

```bash
npm install
npx expo start --web
```

Of na `npx expo start` de `w`-toets drukken. De app opent in je browser.

## Accounts

Accounts en je aantal bezoeken worden **op het apparaat bewaard**
(AsyncStorage). Je blijft dus ingelogd na verversen en je inloggegevens
werken opnieuw nadat je de app sluit. Elk apparaat heeft zijn eigen accounts.

## Alleen voor vaste abonnementhouders

Nieuwe accounts hebben een **activatiecode** nodig (de code die op de
seizoenskaart/abonnement staat). Die code staat **nergens plat in de app of de
repository** — hij wordt alleen gecontroleerd, niet getoond.

Zo regel je het:

- **Met Supabase (aanbevolen)**: maak per gast een eigen code op het
  beheerscherm (`/codes`). Standaard is die **één keer geldig**, gekoppeld aan
  het label (de naam van de gast) — zie *Activatiecodes uitdelen* hieronder.
  Gasten kunnen de lijst niet uitlezen; de controle gebeurt in de database.
- **Zonder Supabase**: zet je eigen code in `.env` als
  `EXPO_PUBLIC_ACCESS_CODE` (of in Vercel → Environment Variables). Staat die
  niet ingevuld, dan gebruikt de app een ingebouwde noodcode — die is
  gecodeerd opgeslagen zodat hij niet met een simpele zoekopdracht te vinden
  is, maar onthoud: een statische app kan geen geheim bewaren.
- **Registreren sluiten**: zet `EXPO_PUBLIC_ACCESS_CODE=` leeg én zet Supabase
  uit (of laat `activation_codes` leeg) — de knop *Registreren* verdwijnt en er
  kan alleen nog ingelogd worden met bestaande accounts.

Zonder goede code krijg je: *"Deze activatiecode klopt niet (meer). Vraag een
nieuwe code bij het park."*

## scripts

| Commando           | Wat het doet                     |
| ------------------ | -------------------------------- |
| `npm start`        | Start de ontwikkelserver         |
| `npm run web`      | Start de app in de browser       |
| `npm run android`  | Open op Android-apparaat/emulator|
| `npm run ios`      | Open op iOS-simulator            |
| `npm run lint`     | Controleer de code op fouten     |
| `npx tsc --noEmit` | Controleer de TypeScript-types    |

## Schermen

- **Login / Registreren** — inloggen, of als abonnementhouder je kaart
  activeren met een activatiecode; foutmeldingen en tips komen in beeld
  (werkt ook in de browser)
- **Dashboard** — bezoekenteller, menu en een bel met het aantal aankomende
  reserveringen
- **Seizoenskaart** — digitale **Seizoenkaart** met een **echte QR-code** die
  verwijst naar de scantoonbank, uniek pasnummer (FF-######), geldig tot en
  met 31 december van het lidmaatschapsjaar (zoals de echte kaart), je
  check-instatus van vandaag en de **echte voordelen** van funforest.nl:
  onbeperkt klimmen, alle vier de klimbossen, unieke parcoursen en geen losse
  tickets
- **Check-in (scantoonbank)** — openbaar scherm voor het personeel: de QR van
  een gast scannen (of het kaartnummer typen) zet het bezoek op het account,
  telt de teller en blokkeert een tweede check-in dezelfde dag
- **Reserveringen** — kies een datum in de **maandkalender** (niet meer vast
  aan 14 dagen), zie per dag de **echte openingstijden** en de tijdslots die
  daarbij passen. Dagen "op aanvraag" of gesloten zijn duidelijk uitgeschakeld,
  6 plekken per slot, bevestigen, bekijken en annuleren
- **Beheer (voor het park)** — overzicht van alle reserveringen per dag en
  tijdslot met de namen erbij en hoe vol elk slot is (`x/6`), inclusief de
  lege slots, want die wil het park juist zien. Alleen voor beheerders
  (`profiles.is_admin`); zonder Supabase staat het scherm er ook (lokale
  modus) met een duidelijke waarschuwing dat je alleen dit apparaat ziet
- **Profiel** — accountgegevens, wachtwoord wijzigen, meldingen aan/uit en
  uitloggen
- **Informatie** — het echte adres, telefoonnummer en e-mail van Fun Forest
  Venlo, de eerstkomende dagen met live openingstijden en werkende bel-, route-,
  mail- en FAQ-knoppen

## Echte openingstijden

De app haalt de openingstijden op uit de open kalender van funforest.nl
(`wp-json/funforest-airtable/v1/calendar`, met `start`/`end`), gefilterd op
**Fun Forest Venlo**. De lokale tijden staan in `label`/`display_value`
(`opening_time` is UTC).

- Resultaat wordt 6 uur in AsyncStorage bewaard en daarna op de achtergrond
  ververst (`lib/parkHours.js`)
- Geen netwerk én geen cache? Dan valt de app terug op een statisch
  weekpatroon, met een duidelijke waarschuwing in beeld
- Zo ver vooruit als de kalender gevuld is (nu t/m 31 december); dagen die
  nog niet gepubliceerd zijn tonen "kalender volgt"

## Op telefoon én laptop

De app schaalt mee zonder in te zoomen: de viewport staat op
`width=device-width, initial-scale=1`, invoervelden zijn 16 px (geen
automatische zoom op mobiel) en op brede schermen staat alles in een gecentreerde
kolom van maximaal 560 px, zodat niets wordt uitgerekt. Getest op 320–390 px
(telefoon) en 1440 px (laptop).

## Publiceren op Vercel

De app is een statische export (een HTML-bestand per route), dus Vercel kan
hem zo serveren. [`vercel.json`](vercel.json) staat er al klaar volgens de
Expo-handleiding (`cleanUrls: true`, output `dist`).

```bash
npm i -g vercel      # eenmalig
vercel               # eerste keer: vragen beantwoorden
vercel --prod        # live zetten
```

Of koppel de repo in het Vercel-dashboard; de build-commando's komen uit
`vercel.json`. Zo is het nu ingericht: het Vercel-project **funforest-app** bouwt
uit de GitHub-repo `Eliyah2/funforest-app`, terwijl de bewaarrepo `origin` =
`Eliyah2/funforrest` is. Push daarom na elke commit naar beide remotes, anders
komt de update niet live:

```bash
git push origin main              # bewaarrepo (funforrest)
git push funforest-app main       # Vercel bouwt hieruit -> live
```

Lokaal de productiebuild bekijken zoals Vercel hem serveert:

```bash
npx expo export -p web
node tools/serve-dist.js 8090   # http://localhost:8090
```

Bewaren van gegevens gebeurt in de browser (localStorage) van de bezoeker:
per apparaat, blijft staan na herladen, en gaat weg bij wissen van
browserdata of bij een ander domein.

## Backend: Supabase (gedeelde passen & reserveringen)

Zonder configuratie draait de app **lokaal**: accounts, bezoeken en
reserveringen staan dan per apparaat opgeslagen. Wil je dat gasten overal
dezelfde pas en boekingen hebben — en dat je broer ziet wie er gereserveerd
heeft — koppel dan Supabase (gratis tier volstaat):

1. Maak een gratis project op <https://supabase.com>
2. Plak [`supabase/schema.sql`](supabase/schema.sql) in **SQL Editor → New query**
   en draai het uit (tabellen, RLS en de capaciteitsregel)
3. Kopieer `.env.example` naar `.env` en vul **Project URL** + **anon key** in
   (Project Settings → API)
4. Zet in **Authentication → Sign In / Providers → Email** de schakelaar
   *Confirm email* uit, anders moet elke nieuwe gast eerst een
   bevestigingsmail openen
5. Herstart met `npm start`; klaar

Wat je dan krijgt:

- **Accounts via Supabase Auth** — wachtwoorden staan dus niet meer in de
  browser (in de lokale modus stonden ze wel in localStorage)
- **Gedeelde passen** — pasnummer, bezoeken en "lid sinds" overal gelijk
- **Gedeelde reserveringen** — één overzicht voor je broer; de regel
  *max 6 per tijdslot, geen dubbele boekingen* wordt **in de database**
  afgedwongen (functie `book_slot`), niet alleen in de app
- **Row Level Security** — iedereen ziet alleen z'n eigen profiel en
  reserveringen; de beschikbaarheidsteller is zichtbaar voor ingelogde gasten
- De **activatiecode** blijft verplicht bij registreren, en het optionele
  **kaartnummer** gaat naar `profiles.pass_number` en komt in de QR

> Draai je op Vercel? Zet `EXPO_PUBLIC_SUPABASE_URL` en
> `EXPO_PUBLIC_SUPABASE_ANON_KEY` dan ook in *Project Settings → Environment
> Variables* (de `.env` wordt niet meegenomen in de deploy).

## Activatiecodes uitdelen (voor het park)

1. Voer [`supabase/schema.sql`](supabase/schema.sql) uit — daarin zit ook de
   tabel `activation_codes` met bijbehorende regels.
2. Zet jezelf één keer aan als beheerder (SQL Editor):

   ```sql
   update public.profiles set is_admin = true where email = 'broer@funforest.nl';
   ```

3. Log in in de app: er komt een menu-item **Activatiecodes** bij (of open
   direct `/codes`).
4. Klik **Maken** (label optioneel, bijv. "Familie Jansen") → **Kopieer** →
   stuur die code naar de gast. Die vult hem in bij *Activeer je kaart*.
5. Met één tik zet je een code op **Uit**; hoe vaak hij gebruikt is zie je
   ernaast. De lijst is met Row Level Security niet uit te lezen door gasten.

Zonder Supabase is er **géén codescherm**: het menu-item komt alleen bij een
beheerder, en die vlag (`profiles.is_admin`) bestaat dan niet. Deel je nog
geen Supabase-codes, dan geldt de in de app ingebouwde noodcode: die staat
niet als tekst in de repository of in de bundel en is te wijzigen via
`EXPO_PUBLIC_ACCESS_CODE` in `.env` / Vercel. Wil je echt niet dat iemand met
de bron van de site een account maakt, gebruik dan Supabase-codes — die zijn
per gast, worden server-side gecontroleerd en kun je per persoon uitzetten.
Voor live gebruik moeten eerst de Supabase-sleutels in Vercel staan (zie
hierboven), daarna werkt het beheerscherm ook op de site.

> Het doorgeven van die ene gedeelde noodcode (appje of mail) blijft het
> zwakke punt: één persoon deelt hem en iedereen kan registreren. Kies je op
> het codescherm voor **Per gast (1×)**, dan kan elke code maar één keer
> gebruikt worden en blokkeer je die per persoon.

## Check-in via QR-scan (alleen de scan telt)

De QR-code op de seizoenkaart bevat een link naar `/checkin?pass=FF-######`.
Scannen ís de check-in: er is geen knop meer waarmee een gast zelf bezoeken
bijschrijft.

- **Scan = bezoek**: de scantoonbank zet het bezoek op het account en verhoogt
  de teller (`profiles.visits`)
- **Maximaal één keer per dag**: een tweede scan vandaag toont *Vandaag al
  ingecheckt* met het tijdstip van de eerste scan — het telt niet twee keer
  (`unique (user_id, check_date)`)
- **Zonder login**: het personeel hoeft niet ingelogd te zijn; de registratie
  loopt via de databasefunctie `record_checkin` (sectie 6 van
  [`supabase/schema.sql`](supabase/schema.sql))
- **Kaartnummer**: het profielnummer, en anders het nummer dat de app uit het
  e-mailadres berekent — beide herkent de functie
- **Zonder Supabase** werkt scannen alleen op het apparaat waar de accounts
  staan (lokale modus, met een waarschuwing in beeld); met Supabase werkt het
  vanaf elke telefoon van het park

Testen: open de kaart, kopieer het kaartnummer en ga naar
`/checkin?pass=FF-123456` — of gebruik de knop *Volgende scan* om een nummer
in te typen.

## Huisstijl

De kleuren komen 1:1 uit de theme-CSS van funforest.nl — inclusief hun
**donkergroene kopkleur** `#032810` (`.text-secondary-950`), zodat oranje
alleen nog op knoppen, iconen en accenten zit zoals op hun site:

| Rol | Hex | Herkomst |
| --- | --- | --- |
| Primair oranje (CTA) | `#F76D18` | `.bg-cta` / `.bg-primary` |
| Dieper oranje | `#C03D0E` | `.fill-primary-dark` (hover) |
| Koppen donkergroen | `#032810` | `.text-secondary-950` (H1/H2) |
| Bosgroen | `#5CA33F` | secundaire kleur |
| Crème achtergrond | `#FFF7ED` | `.bg-primary-50` |
| Antraciet tekst | `#182230` | `.text-font` |
| Fout-rood | `#DA3A2F` | waarschuwingen |

- Logo: `assets/brand/funforest-logo.png` (oranje, transparante achtergrond)
- App-icoon, splash en favicon zijn eruit gegenereerd. Opnieuw doen:

  ```bash
  powershell -ExecutionPolicy Bypass -File tools\make-icons.ps1
  ```

## Ontwikkeling

```bash
npm run lint        # ESLint
npx tsc --noEmit    # TypeScript-controle
npx expo export --platform web     # productiebouw voor de browser
npx expo export --platform android # productiebouw voor Android
```

## Levering

De werkende app staat in `oplevering/funforest-app.zip`. Opnieuw maken na
wijzigingen:

```bash
npx expo export --platform web
npx expo export --platform android
powershell -ExecutionPolicy Bypass -File tools\make-zip.ps1
```

`tools\make-zip.ps1` pakt alleen de bronbestanden (app, assets, lib, tools,
config) in `oplevering\funforest-app.zip` — node_modules en dist blijven
eruit.
